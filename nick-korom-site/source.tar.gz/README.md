# Nick Korom website migration

Static copy of the public WordPress website with locally preserved theme assets, improved acquisition messaging, completed media links, company contact routes, and Person metadata.

Deploy this directory as a separate Vercel project with Framework Other, no build command, output directory `.`. The preview is noindex until the nickkorom.com domain cutover. Remove the noindex meta and update robots.txt at cutover.

WordPress form submissions are replaced with links to the company funnel. No CMS database or submissions are migrated. Review existing privacy wording against the final hosting and analytics configuration.
